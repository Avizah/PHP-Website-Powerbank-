<?php
			include 'connect.php';
if(isset($_REQUEST['ok'])){
	$xml = new DOMDocument("1.0","UTF-8");
	$xml->load("powerbank.xml");

	$rootTag = $xml->getElementsByTagName("document")->item(0);
	$dataTag = $xml->createElement ("data" );

	$data_merek = $xml->createElement("merek",$_REQUEST['merek']);
	$data_kapasitas = $xml->createElement("kapasitas",$_REQUEST['kapasitas']);
	$data_harga = $xml->createElement("harga",$_REQUEST['harga']);
	$data_portusb = $xml->createElement("portusb",$_REQUEST['portusb']);
	$data_fitur = $xml->createElement("fitur",$_REQUEST['fitur']);

	$dataTag->appendChild($data_merek);
	$dataTag->appendChild($data_kapasitas);
	$dataTag->appendChild($data_harga);
	$dataTag->appendChild($data_portusb);
	$dataTag->appendChild($data_fitur);

	$rootTag->appendChild($dataTag);

	$xml->save("powerbank.xml");

$q=mysqli_query($koneksi, "INSERT INTO powerbank VALUES (NULL, '".$_REQUEST['merek']."', '".$_REQUEST['kapasitas']."', '".$_REQUEST['harga']."', '".$_REQUEST['portusb']."', '".$_REQUEST['fitur']."')");

// if(!$q ){
// echo "<script>alert('Gagal di tambahkan!');</script>";
// } else{
echo "<script>alert('Data berhasil di tambahkan!');</script>";
echo '  <script language="javascript">
              window.location.href="http://localhost/andipowerbank/index.php";
              </script> '; 
}

?>