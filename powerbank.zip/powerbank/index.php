<!DOCTYPE html>
<html>
  <head>

    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="css/style.css">
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>GOBENK</title>
  </head>

  <body>

    <!-- Navbar -->
<div class="navbar-fixed ">
  <nav class="white">
    <div class="nav-wrapper">
<img class="logohome" src="img/GOPB.png">
      <ul class="right hide-on-med-and-down">
        <li><a href="badges.html" class="about">About</a></li>
      </ul>
    </div>
  </nav>
</div>

<!-- Slideer -->
<div class="slider">
  <ul class="slides">
    <li>
      <img src="img/slider/pb1.jpg" class="slider">
      <div class="caption center-align">
        <h1>Mau cari Powerbank?</h1>
        <h3 class="light grey-text text-lighten-3">Dapatkan info powerbank, di GOBENK !!!</h3>
        <br><br><br>
        <form class="searchform"  action="action_page.php" method="POST">
          <input type="text" name="keyword" placeholder="Search..">
              <button type="submit" name="ok" class="myButton"><span>Cari</span></button>
        </form>
      </div>
    </li>
  </ul>
</div>


<footer>
<div id="container">
   <div class="footer">
      Copyright by Andi Purnomo
   </div>
</div>
</footer>

    <!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script>
    const sidenav = document.querySelectorAll('.sidenav');
    M.Sidenav.init(sidenav);

    const slider = document.querySelectorAll('.slider');
    M.Slider.init(slider, {
      indicators: false,
      height: 10000,
      transition: 600,
      interval: 3000
    });
    </script>
  </body>
</html>
