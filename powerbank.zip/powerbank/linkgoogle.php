<?php
include 'connect.php';

public function google($baris){
	echo '<script language="javascript">
              window.location.href="http://www.google.com";
              </script>' ;
}

 $select= mysqli_query($koneksi, " SELECT * FROM powerbank");
    while($baris = mysqli_fetch_array($select)){
        ?>
  
           <?php $baris['linkpembelian']?>
            
      }

?>