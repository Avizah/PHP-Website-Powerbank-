<!DOCTYPE html>
<html>
  <head>

    <!-- Datatables -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="css/materialize.css"  media="screen,projection"/>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Pencarian PB</title>
  </head>

  <body>
    <!-- Navbar -->
<div class="navbar-fixed ">
  <nav class="white">
    <div class="nav-wrapper">
        <img class="logo" src="img/GOPB.png">
      <ul class="right hide-on-med-and-down">
      </ul>
    </div>
  </nav>
</div>

<div class="container">
  <div class="caption">
    <form class="searchformpage" action="action_page.php" method="POST">
      <input type="text" name="keyword" placeholder="<?php $kategori?>">
          <button type="submit" name="ok" class="myButton"><span>Cari</span></button>
    </form>
  </div>
</div>

<div class="slider">
  <ul class="slides">
    <li>
      <img src="img/powerbank.jpg" class="slider">
      <div class="caption center-align">
        
        <table width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>No</th>
            <th>Merek</th>
            <th>Kapasitas</th>
            <th>Harga</th>
            <th>Port</th>
            <th>Fitur</th>
        </tr>
    </thead>
    <?php
    include 'connect.php';
    $no = 1;
    $kategori = $_POST['keyword'];
    if($kategori !=''){
      $select = mysqli_query($koneksi , "SELECT * FROM powerbank WHERE merek LIKE '%$kategori%' or kapasitas LIKE '%$kategori%' or harga LIKE '%$kategori%' or portusb LIKE '%$kategori%' or fitur LIKE '%$kategori%' ");  
    }
        else{
    $select= mysqli_query($koneksi, " SELECT * FROM powerbank");
}
if(mysqli_num_rows($select)){   
    while($baris = mysqli_fetch_array($select)){
        ?>
    <tbody>
        <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $baris['merek'] ?></td>
            <td><?php echo $baris['kapasitas'].' mah' ?></td>
            <td><?php echo 'Rp '.$baris['harga'] ?></td>
            <td><?php echo $baris['portusb'] ?></td>
            <td><?php echo $baris['fitur'] ?></td>
        </tr>
<?php }}else{
     echo '<tr><td>Tidak Ada Data</td></tr>';
            }?>
    </tbody>

</table>
  </div>
</div>
      </div>
    </li>
  </ul>
</div>
<!-- <div>
  <img class="powerbank" src="img/powerbank.jpg">
</div> -->
<br>

    </form>
    <br><br>
    




<!-- sidenav -->
<!-- <ul class="sidenav" id="mobile-nav">
  <li><a href="#">Download Apps</a></li>
  <li><a href="badges.html">Promosikan iklan Anda</a></li>
  <li><a href="badges.html">Masuk</a></li>
</ul> -->
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/jquery-3.1.0.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
    <!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script>
    const sidenav = document.querySelectorAll('.sidenav');
    M.Sidenav.init(sidenav);

    const slider = document.querySelectorAll('.slider');
    M.Slider.init(slider, {
      indicators: false,
      height: 1000,
      transition: 600,
      interval: 3000
    });

    // $.extend( true, $.fn.dataTable.defaults, {
    //     "searching": false,
    //     "ordering": false
    // } );

        $(document).ready(function(){
            $('#tabel-data').DataTable();
        });
    </script>

    </script>
  </body>
</html>
