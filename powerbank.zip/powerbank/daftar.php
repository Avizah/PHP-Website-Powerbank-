<html>
<head>
	<title></title>
</head>
		<body>
			<form action="simpanform.php" method="POST">
        <table>

            <tr>
                <td>Nama Merek</td>
                <td><input type="text" name="merek" placeholder="merek"></input></td>
            </tr>
            <tr>
                <td>Kapasitas</td>
                <td><input type="text" name="kapasitas" placeholder="kapasitas"></input></td>
            </tr>
            <tr>
                <td>Harga</td>
                <td><input type="text" name="harga"  placeholder="harga"></input></td>
            </tr>
            <tr>
                <td>Port USB</td>
                <td><input type="text" name="portusb" placeholder="Port Usb"></input></td>
            </tr>
			<tr>
                <td>Fitur</td>
                <td><input type="text" name="fitur" placeholder="fitur"></input></td>
            </tr>
            <tr><td></td></tr>
            <tr>
               
                <td><input type="submit" name="ok" value="Simpan"></input></td>
            </tr>
        </table>
    </form>
			
		</body></html>