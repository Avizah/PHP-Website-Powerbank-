<?php
// $host = "localhost";
// $user = "root"; //adjust according to your mysql setting
// $pass = ""; //adjust according to your mysql setting
// $dbName = "book";
$koneksi = mysqli_connect('localhost', 'root', '','seminar_smartweb');
// $koneksi = mysqli_connect($host, $user, $pass,$dbName);


?>